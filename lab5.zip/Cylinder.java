package hus.oop.lab5;

public class Cylinder extends Circle {
    private double height = 1.0;

    public Cylinder(){

    }

    public Cylinder(double r) {
        super(r);
    }

    public Cylinder(double r, double height) {
        super(r);
        this.height = height;
    }

    public Cylinder(double r, String color, double height) {
        super(r, color);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getArea(){
        return 2 * Math.PI * this.getRadius() * height + 2 * this.getRadius() * this.getRadius() * Math.PI;
    }

    public double getVolume() {
        return Math.PI * this.getRadius() * this.getRadius() * this.height;
    }

    public String toString(){
        return "Cylinder: subclass of " + super.toString() + " height= " + this.height;
    }
}
