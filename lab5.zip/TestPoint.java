package hus.oop.lab5;

public class TestPoint{
    public static void main(String[] args) {
        // Test Point2D
        Point2D point2D = new Point2D(3.5f, 4.5f);
        System.out.println("Initial Point2D: " + point2D);

        point2D.setX(5.0f);
        point2D.setY(6.0f);
        System.out.println("Updated Point2D: " + point2D);

        point2D.setXY(7.5f, 8.5f);
        System.out.println("After setXY Point2D: " + point2D);

        float[] coords2D = point2D.getXY();
        System.out.println("Point2D coordinates: (" + coords2D[0] + ", " + coords2D[1] + ")");

        // Test Point3D
        Point3D point3D = new Point3D(1.5f, 2.5f, 3.5f);
        System.out.println("\nInitial Point3D: " + point3D);

        point3D.setX(4.0f);
        point3D.setY(5.0f);
        point3D.setZ(6.0f);
        System.out.println("Updated Point3D: " + point3D);

        point3D.setXYZ(7.0f, 8.0f, 9.0f);
        System.out.println("After setXYZ Point3D: " + point3D);

        float[] coords3D = point3D.getXYZ();
        System.out.println("Point3D coordinates: (" + coords3D[0] + ", " + coords3D[1] + ", " + coords3D[2] + ")");
    }
}
