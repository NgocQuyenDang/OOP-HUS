package hus.oop.lab5;

public class Circle2 extends Shape{
    private double radius = 1.0;

    public Circle2(){

    }

    public Circle2(double radius){
        this.radius = radius;
    }

    public Circle2(String color, boolean filled, double radius) {
        super(color, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getPerimeter(){
        return Math.PI * 2 * this.radius;
    }

    public double getArea(){
        return Math.PI * this.radius * this.radius;
    }

    public String toString(){
        return "Circle[" + super.toString() + ",radius = " + this.radius;
    }
}
