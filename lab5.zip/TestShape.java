package hus.oop.lab5;

public class TestShape {
    public static void main(String[] args) {
        // Test Shape
        Shape shape = new Shape("blue", false);
        System.out.println(shape);

        // Test Circle2
        Circle2 circle = new Circle2("yellow", true, 5.0);
        System.out.println(circle);
        System.out.println("Circle Area: " + circle.getArea());
        System.out.println("Circle Perimeter: " + circle.getPerimeter());

        // Test Rectangle
        Rectangle rectangle = new Rectangle("green", true, 4.0, 6.0);
        System.out.println(rectangle);
        System.out.println("Rectangle Area: " + rectangle.getArea());
        System.out.println("Rectangle Perimeter: " + rectangle.getPerimeter());

        // Test Square
        Square square = new Square(4.0, "red", false);
        System.out.println(square);
        System.out.println("Square Area: " + square.getArea());
        System.out.println("Square Perimeter: " + square.getPerimeter());
    }
}
