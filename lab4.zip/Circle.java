package lab4;

public class Circle {
    private double radius;
    private String color;

    public Circle(){
        radius = 1.0;
        color = "red";
    }

    public Circle (double r){
        radius = r;
        color = "red";
    }

    public Circle(double r, String color){
        this.radius = r;
        this.color = color;
    }

    public double getRadius(){
        return radius;
    }

    public String getColor(){
        return this.color;
    }

    public double getArea(){
        return Math.PI * radius * radius;
    }
    public double getCircumference(){
        return Math.PI * 2 * radius;
    }

    public void setRadius(double radius){
        this.radius = radius;
    }

    public void setColor(String color){
        this.color = color;
    }

    public String toString(){
        return "Circle[radius = " + this.radius + " color = " + this.color;
    }

    public static void main(String[] args){
        Circle circle1 = new Circle();
        System.out.println("The circle has radius of " + circle1.getRadius() + " and area of " + circle1.getArea());

        Circle circle2 = new Circle(2.0);
        System.out.println("The circle has radius of " + circle2.getRadius() + " and area of " + circle2.getArea());

        Circle circle3 = new Circle(3.0, "blue");
        System.out.println("The circle has radius of " + circle3.getRadius() + " and area of " + circle3.getArea() + " " +  circle3.getColor());

        Circle circle4 = new Circle(4.5);
        System.out.println(circle4);
        System.out.println(circle4.toString());
        System.out.println("The C of circle4 is : " + circle4.getCircumference());
    }
}
