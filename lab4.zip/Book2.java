package lab4;

public class Book2 {
    private String name;
    private Author[] authors;
    private double price;
    private int qty =  0;

    public Book2(String name, Author[] authors, double price) {
        this.name = name;
        this.authors = authors;
        this.price = price;
    }

    public Book2(String name, Author[] authors, double price, int qty) {
        this.name = name;
        this.authors = authors;
        this.price = price;
        this.qty = qty;
    }

    public String getName() {
        return name;
    }

    public Author[] getAuthor() {
        return authors;
    }

    public double getPrice() {
        return price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAuthorNames(){
        String authorNames = "";
        for (int i = 0; i < authors.length; i++){
            authorNames += authors[i].getName();
        }
        return authorNames;
    }

    public String printAuthors(){
        String authorsInfo = "";
        for (Author authors : authors){
            if (!authorsInfo.isEmpty()){
                authorsInfo += " , ";
            }
            authorsInfo += authors.toString();
        }
        return authorsInfo;
    }

    public String toString(){
        return "Book[name = " + this.name + "," + this.printAuthors() + ", price = " + this.price + ",qty = " + this.qty;
    }
}

