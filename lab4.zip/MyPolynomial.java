package lab4;

public class MyPolynomial {
    private double[] coeffs;

    public MyPolynomial(double[] coeffs) {
        this.coeffs = coeffs;
    }

    public int getDegree(){
        return coeffs.length - 1;
    }

    public String toString(){
        String expression = "";
        for (int i = coeffs.length; i >=0; i--){
            if (!expression.isEmpty()){
                expression += "+";
            }
            if (coeffs[i] != 0){
                expression += coeffs[i] + "x^" + i;
            }
        }
        return expression;
    }

    public double evaluate(double x){
        double result = 0;

        for (int i = 0 ; i < coeffs.length; i++){
            result += coeffs[i] * Math.pow(x, i);
        }
        return result;
    }

    public MyPolynomial add(MyPolynomial right) {
        int maxDegree = Math.max(this.getDegree(), right.getDegree());
        double[] newCoeffs = new double[maxDegree + 1];
        for (int i = 0; i <= maxDegree; i++) {
            double leftCoeff = (i <= this.getDegree()) ? this.coeffs[i] : 0;
            double rightCoeff = (i <= right.getDegree()) ? right.coeffs[i] : 0;
            newCoeffs[i] = leftCoeff + rightCoeff;
        }
        return new MyPolynomial(newCoeffs);
    }

    public MyPolynomial multiply(MyPolynomial right){
        int maxDegree = this.getDegree() + right.getDegree();
        double[] newCoeffs = new double[maxDegree + 1];

        for (int i = 0; i <= this.getDegree(); i++) {
            for (int j = 0; j <= right.getDegree(); j++) {
                newCoeffs[i + j] += this.coeffs[i] * right.coeffs[j];
            }
        }
        return new MyPolynomial(newCoeffs);

    }


}
